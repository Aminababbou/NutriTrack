
using System.Globalization;

namespace NutriTrack;

public partial class AjouterJournalPage : ContentPage
{
    private readonly Aliment _aliment;

    public AjouterJournalPage(Aliment aliment)
    {
        InitializeComponent();

        _aliment = aliment;
        BindingContext = aliment;

        // Informations de l'aliment
        LblNom.Text = aliment.Nom;
        LblCategorie.Text = aliment.Categorie;
        LblCalories100.Text = $"{aliment.Calories} kcal";
        LblProteines100.Text = $"{aliment.Proteines} g";

        // Unit� selon la cat�gorie
        LblUnite.Text =
            aliment.Categorie == "Boissons" ? "ml" : "g";

        // Date par d�faut
        DateConsommationPicker.Date = DateTime.Today;

        // Repas non s�lectionn� par d�faut
        RepasPicker.SelectedIndex = -1;
    }

    // Calcul automatique des calories et prot�ines
    private void OnQuantiteChanged(object sender, TextChangedEventArgs e)
    {
        string texte = e.NewTextValue ?? "";

        if (!double.TryParse(
            texte,
            NumberStyles.Number,
            CultureInfo.CurrentCulture,
            out double quantite) || quantite <= 0)
        {
            LblCalories.Text = "0 kcal";
            LblProteines.Text = "0 g";
            return;
        }

        double calories = _aliment.Calories * quantite / 100;
        double proteines = _aliment.Proteines * quantite / 100;

        LblCalories.Text = $"{calories:F1} kcal";
        LblProteines.Text = $"{proteines:F1} g";
    }

    // Ajouter l'aliment au journal
    private async void OnAjouterClicked(object sender, EventArgs e)
    {
        // V�rifier la quantit�
        if (!double.TryParse(
            TxtQuantite.Text,
            NumberStyles.Number,
            CultureInfo.CurrentCulture,
            out double quantite) || quantite <= 0)
        {
            await DisplayAlert(
                "Quantit� invalide",
                "Veuillez saisir une quantit� sup�rieure � 0.",
                "OK");

            return;
        }

        // D�finir la quantit� maximale
        double quantiteMax =
            _aliment.Categorie == "Boissons" ? 5000 : 2000;

        string unite =
            _aliment.Categorie == "Boissons" ? "ml" : "g";

        // V�rifier que la quantit� ne d�passe pas la limite
        if (quantite > quantiteMax)
        {
            await DisplayAlert(
                "Quantit� trop �lev�e",
                $"La quantit� maximale autoris�e est de {quantiteMax} {unite}.",
                "OK");

            return;
        }

        // V�rifier le repas
        if (RepasPicker.SelectedIndex == -1)
        {
            await DisplayAlert(
                "Repas manquant",
                "Veuillez choisir un repas.",
                "OK");

            return;
        }

        try
        {
            // Enregistrer dans SQLite
            JournalService.Ajouter(
                _aliment.Id,
                quantite,
                RepasPicker.SelectedItem.ToString()!,
                DateConsommationPicker.Date);

            await DisplayAlert(
                "Succ�s",
                "L'aliment a �t� ajout� au journal.",
                "OK");

            // Retour � la page pr�c�dente
            await Navigation.PopAsync();
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "Erreur",
                "Impossible d'ajouter l'aliment : " + ex.Message,
                "OK");
        }
    }
}

