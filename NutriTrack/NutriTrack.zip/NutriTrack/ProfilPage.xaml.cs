
using System.Globalization;

namespace NutriTrack;

public partial class ProfilPage : ContentPage
{
    bool _pret = false;

    public ProfilPage()
    {
        InitializeComponent();

        _pret = true;
        VerifierTout();
    }

    // Quand l'utilisateur modifie un champ
    void OnTexteChange(object? sender, TextChangedEventArgs e)
    {
        if (_pret)
            VerifierTout();
    }

    // Quand l'utilisateur choisit le sexe ou l'activit�
    void OnChoixChange(object? sender, EventArgs e)
    {
        if (_pret)
            VerifierTout();
    }

    // Quand l'utilisateur choisit son objectif
    void OnObjectifChange(object? sender, EventArgs e)
    {
        if (!_pret) return;

        int objectif = ObjectifPicker.SelectedIndex;

        PoidsViseLayout.IsVisible = (objectif == 1 || objectif == 2);

        PoidsViseEntry.Text = "";

        if (objectif == 1)
            PoidsViseLabel.Text = "Poids vis� (kg) : inf�rieur � votre poids actuel";

        if (objectif == 2)
            PoidsViseLabel.Text = "Poids vis� (kg) : sup�rieur � votre poids actuel";

        VerifierTout();
    }

    // V�rifier tous les champs
    bool VerifierTout()
    {
        string eAge = VerifierAge(AgeEntry.Text);
        string eTaille = VerifierTaille(TailleEntry.Text);
        string ePoids = VerifierPoids(PoidsEntry.Text);

        bool objectifChoisi = ObjectifPicker.SelectedIndex >= 0;

        string eVise = "";

        if (objectifChoisi)
        {
            eVise = VerifierPoidsVise(
                ObjectifPicker.SelectedIndex,
                PoidsEntry.Text,
                TailleEntry.Text,
                PoidsViseEntry.Text);
        }

        // Afficher les erreurs
        AfficherErreur(AgeErreur, eAge, AgeEntry.Text);
        AfficherErreur(TailleErreur, eTaille, TailleEntry.Text);
        AfficherErreur(PoidsErreur, ePoids, PoidsEntry.Text);
        AfficherErreur(PoidsViseErreur, eVise, PoidsViseEntry.Text);

        // V�rifier les choix obligatoires
        bool sexeChoisi = SexePicker.SelectedIndex >= 0;
        bool activiteChoisie = ActivitePicker.SelectedIndex >= 0;

        bool valide =
            eAge == "" &&
            eTaille == "" &&
            ePoids == "" &&
            eVise == "" &&
            sexeChoisi &&
            activiteChoisie &&
            objectifChoisi;

        ValiderButton.IsEnabled = valide;

        return valide;
    }

    // Contr�le de l'�ge
    string VerifierAge(string? texte)
    {
        if (string.IsNullOrWhiteSpace(texte))
            return "Champ obligatoire.";

        if (!int.TryParse(texte, out int age))
            return "Entrez un nombre entier.";

        if (age < 18 || age > 100)
            return "L'�ge doit �tre compris entre 18 et 100 ans.";

        return "";
    }

    // Contr�le de la taille
    string VerifierTaille(string? texte)
    {
        if (string.IsNullOrWhiteSpace(texte))
            return "Champ obligatoire.";

        if (!int.TryParse(texte, out int taille))
            return "Entrez un nombre entier.";

        if (taille < 120 || taille > 230)
            return "La taille doit �tre comprise entre 120 et 230 cm.";

        return "";
    }

    // Contr�le du poids
    string VerifierPoids(string? texte)
    {
        if (string.IsNullOrWhiteSpace(texte))
            return "Champ obligatoire.";

        if (!LireDecimal(texte, out double poids))
            return "Entrez un nombre valide (ex. 72,5).";

        if (poids < 30 || poids > 300)
            return "Le poids doit �tre compris entre 30 et 300 kg.";

        return "";
    }

    // Contr�le du poids vis�
    string VerifierPoidsVise(
        int objectif,
        string? poidsTexte,
        string? tailleTexte,
        string? viseTexte)
    {
        // Garder son poids : pas besoin de poids vis�
        if (objectif == 0)
            return "";

        if (string.IsNullOrWhiteSpace(viseTexte))
            return "Champ obligatoire.";

        if (!LireDecimal(viseTexte, out double vise))
            return "Entrez un nombre valide (ex. 68,5).";

        if (vise < 30 || vise > 300)
            return "Le poids vis� doit �tre compris entre 30 et 300 kg.";

        // Il faut d'abord un poids actuel et une taille valides
        if (VerifierPoids(poidsTexte) != "" ||
            VerifierTaille(tailleTexte) != "")
        {
            return "Saisissez d'abord un poids actuel et une taille valides.";
        }

        LireDecimal(poidsTexte, out double poids);
        int taille = int.Parse(tailleTexte!);

        double metres = taille / 100.0;
        double imcVise = vise / (metres * metres);

        if (objectif == 1)
        {
            if (vise > poids - 1)
                return "Pour perdre du poids, le poids vis� doit �tre inf�rieur d'au moins 1 kg � votre poids actuel.";

            if (imcVise < 18.5)
                return "Objectif trop bas pour votre taille (IMC inf�rieur � 18,5).";
        }
        else if (objectif == 2)
        {
            if (vise < poids + 1)
                return "Pour prendre du poids, le poids vis� doit �tre sup�rieur d'au moins 1 kg � votre poids actuel.";

            if (imcVise > 30)
                return "Objectif trop �lev� pour votre taille (IMC sup�rieur � 30).";
        }

        return "";
    }

    // Transformer le texte en nombre d�cimal
    bool LireDecimal(string? texte, out double valeur)
    {
        valeur = 0;

        if (string.IsNullOrWhiteSpace(texte))
            return false;

        string t = texte.Trim().Replace(',', '.');

        bool ok = double.TryParse(
            t,
            NumberStyles.AllowDecimalPoint,
            CultureInfo.InvariantCulture,
            out valeur);

        return ok && double.IsFinite(valeur);
    }

    // Afficher le message d'erreur
    void AfficherErreur(Label label, string erreur, string? texte)
    {
        label.Text = erreur;

        label.IsVisible =
            erreur != "" &&
            !string.IsNullOrEmpty(texte);
    }

    // Quand l'utilisateur clique sur Valider
    async void OnValiderClicked(object? sender, EventArgs e)
    {
        // V�rification finale
        if (!VerifierTout())
            return;

        LireDecimal(PoidsEntry.Text, out double poids);

        int objectif = ObjectifPicker.SelectedIndex;

        double vise = poids;

        if (objectif != 0)
            LireDecimal(PoidsViseEntry.Text, out vise);

        // Cr�ation de l'objet Model
        Profil profil = new Profil
        {
            Sexe = SexePicker.SelectedItem?.ToString() ?? "",
            Age = int.Parse(AgeEntry.Text),
            TailleCm = int.Parse(TailleEntry.Text),
            PoidsKg = poids,
            Activite = ActivitePicker.SelectedItem?.ToString() ?? "",
            Objectif = objectif,
            PoidsViseKg = vise
        };

        // Envoyer l'objet au Service pour l'enregistrement
        ProfilService.Enregistrer(profil);

        await DisplayAlert("Profil","Votre profil et votre objectif sont enregistr�s.","OK");
        await Navigation.PushAsync(new ObjectifPage());

    }
}
